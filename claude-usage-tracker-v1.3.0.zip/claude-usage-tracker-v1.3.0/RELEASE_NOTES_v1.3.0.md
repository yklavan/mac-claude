# 🎉 Claude Usage Tracker v1.3.0 - Release Notes

**Release Date:** February 11, 2025

---

## 🚀 What's New

### Major Improvements

#### 🔒 **Single Instance Lock**
- **No more duplicate apps** — Only one instance of Claude Usage Tracker can run at a time
- **Smart window focus** — If you try to launch a second instance, the existing window automatically appears and focuses
- **Prevents conflicts** — Eliminates multiple browser instances fighting over the same profile

#### 🧹 **Automatic Browser Process Cleanup**
- **Auto-detection on startup** — Automatically finds and kills stale browser processes before launching
- **No more "browser already running" errors** — The dreaded startup error is now a thing of the past
- **Clean slate every time** — Each launch starts with a fresh browser instance

#### 🔄 **Proper App Quit Handling**
- **Graceful shutdown** — Browser processes are cleanly terminated when you quit the app
- **No zombie processes** — Prevents browser instances from staying alive after app exit
- **Memory leak prevention** — Ensures all resources are properly released

#### 🔧 **Force Restart Browser Button**
- **Emergency recovery tool** — New red button in Settings tab for manual browser restart
- **One-click solution** — Kills all browser processes and resets everything with a single click
- **Helpful when stuck** — Perfect for when the browser becomes unresponsive

#### 🏷️ **Single Tab Enforcement**
- **One tab only** — Browser now maintains exactly ONE tab at all times
- **No tab accumulation** — Prevents multiple tabs from opening during refresh cycles
- **Cleaner browser window** — Dedicated tab just for Claude.ai usage stats

#### 🛡️ **Enhanced Stability**
- **Better crash recovery** — Improved handling of browser crashes and detached instances
- **Smarter page management** — Validates and reuses existing tabs instead of creating new ones
- **Reduced memory footprint** — Eliminates unnecessary tabs and processes

---

## 🔧 Technical Changes

### Code Improvements

**`main.js`**
- Added `app.requestSingleInstanceLock()` to prevent multiple app instances
- Added `second-instance` event handler to focus existing window
- Added `before-quit` event handler to cleanup browser processes
- Added IPC listeners for browser cleanup coordination

**`scraper.js`**
- New `killStaleBrowserProcesses()` method for automatic cleanup
- Modified `initialize()` to close all existing tabs and create exactly one
- Improved `getValidPage()` to enforce single-tab policy
- Enhanced error handling and recovery mechanisms

**`renderer.js`**
- New "Force Restart Browser" button handler
- Added `app-quitting` IPC listener for cleanup on app exit
- Improved cleanup in `beforeunload` event
- Better state management for tracking start/stop

**`index.html`**
- Added new "Force Restart Browser" button with warning box
- Red gradient styling to indicate emergency/destructive action

---

## 📋 Upgrade Instructions

### If you're upgrading from v1.2.3:

1. **Quit the old version** completely (use "Quit" from menu bar)
2. **Download v1.3.0** (or run `npm install` if building from source)
3. **Launch the new version**
4. That's it! All your settings are preserved.

### First-time users:

Follow the standard installation instructions in the main README.

---

## 🐛 Bug Fixes

- ✅ Fixed: "Browser already running" error on startup
- ✅ Fixed: Multiple tabs opening and accumulating over time
- ✅ Fixed: Zombie browser processes after app quit
- ✅ Fixed: Multiple app instances causing conflicts
- ✅ Fixed: Browser processes not terminating cleanly

---

## 🔮 What's Next?

Potential features for future releases:
- Customizable refresh intervals
- Notification thresholds
- Usage history graphs
- Export usage data to CSV
- Support for multiple Claude accounts

---

## 📝 Known Issues

- None reported yet! If you find any, please open an issue on GitHub.

---

## 🙏 Acknowledgments

Thank you to all users who reported issues and suggested improvements!

---

## 📄 Full Changelog

**v1.3.0** (February 11, 2025)
- 🔒 Single instance lock — prevents multiple copies of the app from running
- 🧹 Auto-cleanup of stale browser processes on startup
- 🔄 Proper app quit handling with browser cleanup
- 🔧 Force Restart Browser button in Settings tab
- 🏷️ Single tab enforcement — browser maintains exactly ONE tab
- 🛡️ Improved browser process management and crash recovery
- ✨ Enhanced stability and eliminated common errors

**v1.2.3** (Previous)
- 🚀 Tracking starts automatically after login
- 🐛 Fixed "Start Tracking" double-click bug

---

**Enjoy the improved stability and reliability! 🎉**
