# Technical Changes - v1.3.0

This document outlines all technical modifications made in version 1.3.0.

---

## Files Modified

### 1. `package.json`
**Changes:**
- Updated version from `1.2.3` to `1.3.0`

```json
"version": "1.3.0"
```

---

### 2. `main.js`
**Changes:**

#### Added Single Instance Lock (Lines 5-21)
```javascript
// Single instance lock - prevent multiple instances of the app
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  console.log('Another instance is already running. Exiting...');
  app.quit();
} else {
  // Someone tried to run a second instance, focus our window instead
  app.on('second-instance', (event, commandLine, workingDirectory) => {
    console.log('Second instance attempted, focusing existing window');
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    }
  });
}
```

#### Added App Quit Handler (Lines 198-209)
```javascript
// Handle app quit - cleanup browser
app.on('before-quit', () => {
  console.log('App quitting, cleaning up browser...');
  if (mainWindow) {
    mainWindow.webContents.send('app-quitting');
  }
});

// Listen for browser cleanup confirmation
ipcMain.on('browser-cleanup-done', () => {
  console.log('Browser cleanup completed');
});
```

**Purpose:**
- Prevent multiple app instances from running simultaneously
- Focus existing window when second instance is attempted
- Properly cleanup browser processes on app exit

---

### 3. `scraper.js`
**Changes:**

#### Added killStaleBrowserProcesses Method (Lines 14-27)
```javascript
killStaleBrowserProcesses() {
  try {
    console.log('Checking for stale browser processes...');
    execSync('pkill -f "ClaudeUsageTracker"', { stdio: 'ignore' });
    console.log('Cleaned up stale browser processes');
    // Wait a moment for processes to fully terminate
    execSync('sleep 1');
  } catch (e) {
    // No processes to kill or pkill failed - that's fine
    console.log('No stale processes found');
  }
}
```

#### Modified initialize Method (Lines 36-83)
**Before:**
```javascript
var pages = await this.browser.pages();
this.page = pages[0] || await this.browser.newPage();
await this.page.setUserAgent('Mozilla/5.0 ...');
```

**After:**
```javascript
// Kill any stale browser processes before launching
this.killStaleBrowserProcesses();

this.executablePath = this.findBrowser();
// ... browser launch code ...

var pages = await this.browser.pages();

// Close ALL existing tabs first
for (var i = 0; i < pages.length; i++) {
  try {
    await pages[i].close();
  } catch (e) {
    console.log('Could not close page:', e.message);
  }
}

// Create exactly ONE tab for the app
this.page = await this.browser.newPage();
await this.page.setUserAgent('Mozilla/5.0 ...');
```

#### Rewrote getValidPage Method (Lines 114-144)
**Purpose:** Enforce single-tab policy and prevent tab accumulation

**Before:**
- Would find existing claude.ai tabs
- Could leave multiple tabs open
- Sometimes created new tabs unnecessarily

**After:**
```javascript
async getValidPage() {
  if (!this.browser) {
    // ... restart logic ...
  }

  // Ensure we have exactly ONE tab
  try {
    var pages = await this.browser.pages();

    // Close ALL extra tabs beyond the first one
    for (var i = 1; i < pages.length; i++) {
      try {
        console.log('Closing extra tab:', i);
        await pages[i].close();
      } catch (e) {
        console.log('Could not close extra tab:', e.message);
      }
    }

    // Validate the first/only page
    if (pages.length > 0) {
      try {
        await pages[0].evaluate('document.title');
        this.page = pages[0];
        return this.page;
      } catch (e) {
        console.log('Page detached, recreating...');
        try {
          await pages[0].close();
        } catch (closeErr) {}
        this.page = await this.browser.newPage();
        return this.page;
      }
    } else {
      // No pages exist, create one
      console.log('No pages found, creating one...');
      this.page = await this.browser.newPage();
      return this.page;
    }
  } catch (error) {
    console.error('Error getting valid page:', error);
    throw error;
  }
}
```

**Purpose:**
- Always maintain exactly ONE browser tab
- Close extra tabs automatically
- Better error handling for detached pages

---

### 4. `renderer.js`
**Changes:**

#### Added Force Restart Browser Handler (Lines 76-129)
```javascript
document.getElementById('force-restart-btn').addEventListener('click', async () => {
  const restartBtn = document.getElementById('force-restart-btn');
  restartBtn.disabled = true;
  restartBtn.textContent = 'Force restarting...';

  updateStatus('🔄 Killing browser processes and restarting...', 'info');

  try {
    // Stop tracking if running
    if (isTracking) {
      isTracking = false;
      if (updateInterval) {
        clearInterval(updateInterval);
        updateInterval = null;
      }
      if (countdownInterval) {
        clearInterval(countdownInterval);
        countdownInterval = null;
      }
      document.getElementById('start-btn').style.display = 'block';
      document.getElementById('stop-btn').style.display = 'none';
    }

    // Close existing scraper
    if (scraper) {
      await scraper.close();
      scraper = null;
    }

    // Kill any stale processes
    const { execSync } = require('child_process');
    try {
      execSync('pkill -f "ClaudeUsageTracker"', { stdio: 'ignore' });
      await new Promise(resolve => setTimeout(resolve, 2000));
    } catch (e) {
      // No processes to kill - that's fine
    }

    updateStatus('✅ Browser processes cleared! Click "Initialize Browser & Login" to restart.', 'success');
    restartBtn.disabled = false;
    restartBtn.textContent = 'Force Restart Browser';

    // Reset setup button
    const setupBtn = document.getElementById('setup-btn');
    setupBtn.disabled = false;
    setupBtn.textContent = 'Initialize Browser & Login';

  } catch (error) {
    updateStatus(`❌ Force restart failed: ${error.message}`, 'error');
    restartBtn.disabled = false;
    restartBtn.textContent = 'Force Restart Browser';
  }
});
```

#### Enhanced beforeunload Cleanup (Lines 224-235)
**Added countdown interval cleanup:**
```javascript
window.addEventListener('beforeunload', async () => {
  if (updateInterval) {
    clearInterval(updateInterval);
  }
  if (countdownInterval) {
    clearInterval(countdownInterval);  // ADDED
  }
  if (scraper) {
    await scraper.close();
  }
});
```

#### Added app-quitting IPC Handler (Lines 237-250)
```javascript
ipcRenderer.on('app-quitting', async () => {
  console.log('App quitting, cleaning up...');
  if (updateInterval) {
    clearInterval(updateInterval);
  }
  if (countdownInterval) {
    clearInterval(countdownInterval);
  }
  if (scraper) {
    await scraper.close();
  }
  ipcRenderer.send('browser-cleanup-done');
});
```

**Purpose:**
- Manual emergency browser restart option
- Proper cleanup of all intervals and processes
- Coordinated shutdown with main process

---

### 5. `index.html`
**Changes:**

#### Added Force Restart Browser Button (Lines 305-310)
```html
<div class="info-text" style="margin-top: 20px; padding: 15px; background: #fff5f5; border-left: 4px solid #fc8181; border-radius: 6px;">
  <strong>⚠️ Browser stuck or not responding?</strong><br>
  Use this button to force-close all browser processes and start fresh.
</div>

<button id="force-restart-btn" class="button" style="background: linear-gradient(135deg, #fc8181 0%, #f56565 100%);">Force Restart Browser</button>
```

**Purpose:**
- Provide visual emergency recovery option
- Red gradient indicates destructive/emergency action
- Clear instructions for when to use it

---

### 6. `README.md`
**Changes:**
- Updated version badge from `1.2.3` to `1.3.0`
- Added comprehensive v1.3.0 changelog section
- Documented all new features and improvements

---

## Summary of Improvements

### Reliability
- ✅ Eliminated "browser already running" errors
- ✅ Prevented zombie browser processes
- ✅ Fixed tab accumulation issues
- ✅ Prevented multiple app instances

### User Experience
- ✅ Added emergency recovery button
- ✅ Automatic cleanup on startup
- ✅ Cleaner browser window (single tab)
- ✅ Better error messages

### Code Quality
- ✅ Better separation of concerns
- ✅ Improved error handling
- ✅ More robust process management
- ✅ Comprehensive cleanup procedures

---

## Testing Checklist

- [x] Single instance lock works (second launch focuses first instance)
- [x] Stale processes are cleaned on startup
- [x] Browser maintains only ONE tab
- [x] Force Restart button works
- [x] App quits cleanly without zombie processes
- [x] Tracking still works after all changes
- [x] Menu bar updates correctly

---

## Migration Notes

**From v1.2.3 to v1.3.0:**
- No database migrations required
- No configuration changes needed
- Fully backward compatible
- User data preserved

---

**Last Updated:** February 11, 2025
